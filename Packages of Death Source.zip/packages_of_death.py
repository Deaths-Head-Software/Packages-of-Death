from __future__ import annotations

import sys
import os
import subprocess
import shutil
import plistlib
from pathlib import Path
from datetime import datetime

# =============================================================================
# Silicon / OpenGL splash fix — MUST be set before QApplication is created
# =============================================================================
os.environ.setdefault("QT_MAC_WANTS_LAYER", "1")

from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt6.QtGui import QColor, QFont, QPainter, QPixmap, QIcon
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QFileDialog, QTextEdit,
    QCheckBox, QComboBox, QGroupBox, QMessageBox, QSplashScreen,
    QProgressBar
)

# =============================================================================
# Global Definitions
# =============================================================================
APP_NAME = "Packages of Death"
ORG_NAME = "Death's Head Software"
VERSION = "1.0.0"

# =============================================================================
# Splash Screen
# =============================================================================
def create_splash():
    """Creates the QSplashScreen with skull ASCII art."""
    try:
        splash_path = Path(__file__).parent / "splash.png"

        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            else:
                if pixmap.width() != 800 or pixmap.height() != 600:
                    pixmap = pixmap.scaled(800, 600,
                                           Qt.AspectRatioMode.KeepAspectRatio,
                                           Qt.TransformationMode.SmoothTransformation)

            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect()
            text_rect.setTop(40)
            text_rect.setBottom(100)
            painter.drawText(text_rect,
                             Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
                             APP_NAME)
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect()
            footer_rect.setTop(pixmap.height() - 100)
            footer_rect.setBottom(pixmap.height() - 50)
            painter.drawText(footer_rect,
                             Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
                             ORG_NAME)
            painter.end()
        else:
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect()
            text_rect.setTop(40)
            text_rect.setBottom(100)
            painter.drawText(text_rect,
                             Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
                             APP_NAME)
            painter.setFont(QFont("Courier", 14))
            skull_art = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            y_start = 250
            for i, line in enumerate(skull_art):
                painter.drawText(250, y_start + (i * 25), line)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect()
            footer_rect.setTop(pixmap.height() - 50)
            footer_rect.setBottom(pixmap.height())
            painter.drawText(footer_rect,
                             Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter,
                             ORG_NAME)
            painter.end()

        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e)
        return None


# =============================================================================
# Package Builder Thread
# =============================================================================
class PackageBuilderThread(QThread):
    """Thread for building packages without blocking the UI."""
    progress = pyqtSignal(str)
    finished = pyqtSignal(bool, str)

    def __init__(self, app_path, output_path, install_location,
                 package_id, version, sign_identity=None):
        super().__init__()
        self.app_path = app_path
        self.output_path = output_path
        self.install_location = install_location
        self.package_id = package_id
        self.version = version
        self.sign_identity = sign_identity

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _purge_quarantine_and_spotlight(self, path: str):
        """Remove com.apple.quarantine xattr and flush Spotlight so the
        installer can't 'relocate' the bundle to a stale Spotlight entry."""
        subprocess.run(["xattr", "-rd", "com.apple.quarantine", path],
                       capture_output=True)
        subprocess.run(["mdimport", "-r", path], capture_output=True)

    def _build_component_plist(self, root_dir: Path, comp_plist_path: Path) -> bool:
        """
        Run pkgbuild --analyze to generate a component plist, then patch it:
          - BundleIsRelocatable  → False   (critical: stops the installer
                                            from chasing Spotlight entries)
          - BundleIsVersionChecked → False  (don't fail if old version exists)
          - BundleOverwriteAction → upgrade (replace whatever is there)
        Returns True on success.
        """
        self.progress.emit("Analyzing bundle to generate component plist…")
        result = subprocess.run(
            ["pkgbuild", "--analyze", "--root", str(root_dir),
             str(comp_plist_path)],
            capture_output=True, text=True
        )
        if result.returncode != 0:
            self.progress.emit(f"pkgbuild --analyze failed: {result.stderr}")
            return False

        # Read, patch, write back
        try:
            with open(comp_plist_path, "rb") as f:
                comps = plistlib.load(f)

            for bundle in comps:
                bundle["BundleIsRelocatable"] = False
                bundle["BundleIsVersionChecked"] = False
                bundle["BundleOverwriteAction"] = "upgrade"

            with open(comp_plist_path, "wb") as f:
                plistlib.dump(comps, f)

            self.progress.emit("Component plist patched (relocation disabled).")
            return True
        except Exception as e:
            self.progress.emit(f"Failed to patch component plist: {e}")
            return False

    # ------------------------------------------------------------------
    # Main run
    # ------------------------------------------------------------------

    def run(self):
        try:
            self.progress.emit("Starting package build…")

            app_path = Path(self.app_path)
            app_name = app_path.name

            # Strip quarantine from source bundle
            self.progress.emit("Stripping quarantine attribute from source bundle…")
            self._purge_quarantine_and_spotlight(str(app_path))

            # Temporary working directory
            temp_dir = Path("/tmp") / f"pkg_build_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            temp_dir.mkdir(exist_ok=True)
            self.progress.emit(f"Working directory: {temp_dir}")

            # Build the root tree:  root/<install_location stripped of leading />/<app>
            root_dir = temp_dir / "root"
            install_rel = self.install_location.lstrip("/")
            payload_dir = root_dir / install_rel
            payload_dir.mkdir(parents=True, exist_ok=True)

            dest_app = payload_dir / app_name
            self.progress.emit(f"Copying bundle with ditto → {dest_app}")
            ditto = subprocess.run(
                ["ditto", str(app_path), str(dest_app)],
                capture_output=True, text=True
            )
            if ditto.returncode != 0:
                self.finished.emit(False, f"ditto failed: {ditto.stderr}")
                shutil.rmtree(temp_dir, ignore_errors=True)
                return

            # Strip quarantine from the copy too
            self._purge_quarantine_and_spotlight(str(dest_app))

            # Generate and patch component plist
            comp_plist = temp_dir / "component.plist"
            if not self._build_component_plist(root_dir, comp_plist):
                self.finished.emit(False,
                    "Could not create component plist. "
                    "Check that pkgbuild is installed (Xcode Command Line Tools).")
                shutil.rmtree(temp_dir, ignore_errors=True)
                return

            # Post-install script: fix permissions + Gatekeeper clear
            scripts_dir = temp_dir / "scripts"
            scripts_dir.mkdir(exist_ok=True)
            postinstall = scripts_dir / "postinstall"
            postinstall.write_text(f"""#!/bin/bash
set -e
TARGET="{self.install_location}/{app_name}"

echo "Post-install: fixing permissions on $TARGET"
chmod -R 755 "$TARGET"
chown -R root:wheel "$TARGET"

# Clear Gatekeeper quarantine on the installed copy
xattr -rc "$TARGET" 2>/dev/null || true

# Re-register with Launch Services
/System/Library/Frameworks/CoreServices.framework/Versions/A/Frameworks/LaunchServices.framework/Versions/A/Support/lsregister -f "$TARGET" 2>/dev/null || true

echo "Post-install complete."
exit 0
""")
            postinstall.chmod(0o755)

            # Build the .pkg
            pkg_cmd = [
                "pkgbuild",
                "--root",            str(root_dir),
                "--component-plist", str(comp_plist),
                "--identifier",      self.package_id,
                "--version",         self.version,
                "--install-location", "/",
                "--scripts",         str(scripts_dir),
            ]
            if self.sign_identity:
                pkg_cmd += ["--sign", self.sign_identity]
                self.progress.emit(f"Signing with: {self.sign_identity}")

            pkg_cmd.append(self.output_path)

            self.progress.emit("Running pkgbuild…")
            self.progress.emit("  " + " ".join(pkg_cmd))

            result = subprocess.run(pkg_cmd, capture_output=True, text=True)
            if result.returncode != 0:
                self.finished.emit(
                    False,
                    f"pkgbuild failed:\n{result.stderr}\n{result.stdout}"
                )
                shutil.rmtree(temp_dir, ignore_errors=True)
                return

            self.progress.emit(result.stdout)

            if not Path(self.output_path).exists():
                self.finished.emit(False, "Package file was not created.")
                shutil.rmtree(temp_dir, ignore_errors=True)
                return

            pkg_size = Path(self.output_path).stat().st_size
            self.progress.emit(f"Package size: {pkg_size / 1024 / 1024:.2f} MB")

            # Quick content listing
            self.progress.emit("Verifying package contents…")
            inspect = subprocess.run(
                ["pkgutil", "--payload-files", self.output_path],
                capture_output=True, text=True
            )
            if inspect.returncode == 0:
                for line in inspect.stdout.strip().split("\n")[:20]:
                    self.progress.emit(f"  {line}")

            shutil.rmtree(temp_dir)
            self.progress.emit("Cleaned up temp files.")

            success_msg = (
                f"Package created successfully!\n\n"
                f"Path:     {self.output_path}\n"
                f"Installs: {self.install_location}/{app_name}\n\n"
                f"IMPORTANT — before installing:\n"
                f"  • Remove any existing copy from {self.install_location}/\n"
                f"    (the installer will upgrade it, but a clean install is safer)\n"
                f"  • Double-click the .pkg and follow the prompts.\n\n"
                f"To check after installation:\n"
                f"  pkgutil --pkg-info {self.package_id}\n"
                f"  ls -la \"{self.install_location}/{app_name}\"\n"
            )
            self.finished.emit(True, success_msg)

        except Exception as e:
            self.finished.emit(False, f"Unexpected error: {e}")


# =============================================================================
# Main Window
# =============================================================================
class MainWindow(QMainWindow):
    """Main application window for Packages of Death."""

    def __init__(self):
        super().__init__()
        self.builder_thread = None
        self.init_ui()
        self.apply_dark_theme()

    def init_ui(self):
        self.setWindowTitle(f"{APP_NAME} v{VERSION}")
        self.setGeometry(100, 100, 900, 750)

        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        layout = QVBoxLayout(central_widget)
        layout.setSpacing(15)
        layout.setContentsMargins(20, 20, 20, 20)

        # Title
        title = QLabel(APP_NAME)
        title.setFont(QFont("Courier", 24, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        # ── Application Selection ──────────────────────────────────────
        app_group = QGroupBox("Application Selection")
        app_layout = QVBoxLayout()
        app_select_layout = QHBoxLayout()
        self.app_path_edit = QLineEdit()
        self.app_path_edit.setPlaceholderText("Select .app bundle to package…")
        app_select_layout.addWidget(self.app_path_edit)
        browse_app_btn = QPushButton("Browse…")
        browse_app_btn.clicked.connect(self.browse_app)
        app_select_layout.addWidget(browse_app_btn)
        app_layout.addLayout(app_select_layout)
        app_group.setLayout(app_layout)
        layout.addWidget(app_group)

        # ── Package Configuration ──────────────────────────────────────
        config_group = QGroupBox("Package Configuration")
        config_layout = QVBoxLayout()

        install_layout = QHBoxLayout()
        install_layout.addWidget(QLabel("Install Location:"))
        self.install_combo = QComboBox()
        self.install_combo.addItems(["/Applications", "/usr/local", "/Library", "Custom…"])
        self.install_combo.currentTextChanged.connect(self.on_install_location_changed)
        install_layout.addWidget(self.install_combo)
        self.custom_install_edit = QLineEdit()
        self.custom_install_edit.setPlaceholderText("Enter custom path…")
        self.custom_install_edit.setVisible(False)
        install_layout.addWidget(self.custom_install_edit)
        config_layout.addLayout(install_layout)

        id_layout = QHBoxLayout()
        id_layout.addWidget(QLabel("Package Identifier:"))
        self.package_id_edit = QLineEdit()
        self.package_id_edit.setPlaceholderText("com.yourcompany.appname")
        self.package_id_edit.setText("com.deathshead.package")
        id_layout.addWidget(self.package_id_edit)
        config_layout.addLayout(id_layout)

        version_layout = QHBoxLayout()
        version_layout.addWidget(QLabel("Version:"))
        self.version_edit = QLineEdit()
        self.version_edit.setText("1.0.0")
        version_layout.addWidget(self.version_edit)
        config_layout.addLayout(version_layout)

        config_group.setLayout(config_layout)
        layout.addWidget(config_group)

        # ── Code Signing ───────────────────────────────────────────────
        signing_group = QGroupBox("Code Signing")
        signing_layout = QVBoxLayout()
        self.sign_checkbox = QCheckBox("Sign package")
        self.sign_checkbox.toggled.connect(self.on_sign_toggled)
        signing_layout.addWidget(self.sign_checkbox)
        sign_id_layout = QHBoxLayout()
        sign_id_layout.addWidget(QLabel("Signing Identity:"))
        self.sign_identity_edit = QLineEdit()
        self.sign_identity_edit.setPlaceholderText(
            "Developer ID Installer: Your Name (XXXXXXXXXX)")
        self.sign_identity_edit.setEnabled(False)
        sign_id_layout.addWidget(self.sign_identity_edit)
        list_identities_btn = QPushButton("List Identities")
        list_identities_btn.clicked.connect(self.list_signing_identities)
        sign_id_layout.addWidget(list_identities_btn)
        signing_layout.addLayout(sign_id_layout)
        signing_group.setLayout(signing_layout)
        layout.addWidget(signing_group)

        # ── Output ─────────────────────────────────────────────────────
        output_group = QGroupBox("Output")
        output_layout = QVBoxLayout()
        output_select_layout = QHBoxLayout()
        self.output_path_edit = QLineEdit()
        self.output_path_edit.setPlaceholderText("Select output .pkg file location…")
        output_select_layout.addWidget(self.output_path_edit)
        browse_output_btn = QPushButton("Browse…")
        browse_output_btn.clicked.connect(self.browse_output)
        output_select_layout.addWidget(browse_output_btn)
        output_layout.addLayout(output_select_layout)
        output_group.setLayout(output_layout)
        layout.addWidget(output_group)

        # ── Progress + Log ─────────────────────────────────────────────
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)

        layout.addWidget(QLabel("Build Log:"))
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setMaximumHeight(160)
        layout.addWidget(self.log_text)

        # ── Buttons ────────────────────────────────────────────────────
        self.build_btn = QPushButton("Build Package")
        self.build_btn.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        self.build_btn.setMinimumHeight(50)
        self.build_btn.clicked.connect(self.build_package)
        layout.addWidget(self.build_btn)

        self.inspect_btn = QPushButton("Inspect Package")
        self.inspect_btn.clicked.connect(self.inspect_package)
        layout.addWidget(self.inspect_btn)

        self.log_btn = QPushButton("View Installation Log")
        self.log_btn.clicked.connect(self.view_install_log)
        layout.addWidget(self.log_btn)

        self.check_btn = QPushButton("Check Installed Packages")
        self.check_btn.clicked.connect(self.check_installed_packages)
        layout.addWidget(self.check_btn)

    # ------------------------------------------------------------------
    # Theme
    # ------------------------------------------------------------------

    def apply_dark_theme(self):
        self.setStyleSheet("""
            QMainWindow, QWidget {
                background-color: #1e1e1e;
                color: #e0e0e0;
            }
            QGroupBox {
                border: 2px solid #3d3d3d;
                border-radius: 5px;
                margin-top: 10px;
                padding-top: 10px;
                font-weight: bold;
            }
            QGroupBox::title {
                color: #e0e0e0;
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
            }
            QLineEdit, QTextEdit, QComboBox {
                background-color: #2d2d2d;
                border: 1px solid #3d3d3d;
                border-radius: 3px;
                padding: 5px;
                color: #e0e0e0;
            }
            QLineEdit:focus, QComboBox:focus {
                border: 1px solid #5a5a5a;
            }
            QPushButton {
                background-color: #3d3d3d;
                border: 1px solid #5a5a5a;
                border-radius: 3px;
                padding: 8px;
                color: #e0e0e0;
            }
            QPushButton:hover  { background-color: #4d4d4d; }
            QPushButton:pressed { background-color: #2d2d2d; }
            QCheckBox, QLabel  { color: #e0e0e0; }
            QProgressBar {
                border: 1px solid #3d3d3d;
                border-radius: 3px;
                text-align: center;
                background-color: #2d2d2d;
            }
            QProgressBar::chunk { background-color: #5a5a5a; }
        """)

    # ------------------------------------------------------------------
    # Slots
    # ------------------------------------------------------------------

    def on_install_location_changed(self, text):
        self.custom_install_edit.setVisible(text == "Custom…")

    def on_sign_toggled(self, checked):
        self.sign_identity_edit.setEnabled(checked)

    def browse_app(self):
        path = QFileDialog.getOpenFileName(
            self, "Select Application Bundle",
            os.path.expanduser("~/Applications"),
            "Applications (*.app)"
        )[0]
        if path:
            self.app_path_edit.setText(path)

    def browse_output(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Package As",
            os.path.expanduser("~/Desktop/package.pkg"),
            "Package Files (*.pkg)"
        )
        if path:
            if not path.endswith(".pkg"):
                path += ".pkg"
            self.output_path_edit.setText(path)

    def list_signing_identities(self):
        try:
            result = subprocess.run(
                ["security", "find-identity", "-v", "-p", "basic"],
                capture_output=True, text=True
            )
            if result.returncode == 0:
                msg = QMessageBox()
                msg.setWindowTitle("Available Signing Identities")
                msg.setText("Available identities:")
                msg.setDetailedText(result.stdout)
                msg.exec()
            else:
                QMessageBox.warning(self, "Error", "Failed to list identities")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to list identities: {e}")

    def log(self, message):
        self.log_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] {message}")

    def build_package(self):
        if not self.app_path_edit.text():
            QMessageBox.warning(self, "Error", "Please select an application bundle")
            return
        if not self.output_path_edit.text():
            QMessageBox.warning(self, "Error", "Please specify output location")
            return
        if not self.package_id_edit.text():
            QMessageBox.warning(self, "Error", "Please specify package identifier")
            return
        if not self.version_edit.text():
            QMessageBox.warning(self, "Error", "Please specify version")
            return

        install_location = self.install_combo.currentText()
        if install_location == "Custom…":
            install_location = self.custom_install_edit.text().strip()
            if not install_location:
                QMessageBox.warning(self, "Error", "Please specify custom install location")
                return

        app_name = Path(self.app_path_edit.text()).name
        target_path = Path(install_location) / app_name

        if target_path.exists():
            reply = QMessageBox.question(
                self,
                "App Already Exists",
                f"A copy exists at:\n  {target_path}\n\n"
                "The component plist already disables relocation, so the installer\n"
                "will upgrade it in place. You can also remove it first for a clean\n"
                "install — the package will reinstall it correctly either way.\n\n"
                "Remove the existing copy before installing?",
                QMessageBox.StandardButton.Yes |
                QMessageBox.StandardButton.No |
                QMessageBox.StandardButton.Cancel
            )
            if reply == QMessageBox.StandardButton.Cancel:
                return
            if reply == QMessageBox.StandardButton.Yes:
                try:
                    result = subprocess.run(
                        ["osascript", "-e",
                         f'do shell script "rm -rf \\"{target_path}\\"" '
                         f'with administrator privileges'],
                        capture_output=True, text=True
                    )
                    if result.returncode == 0:
                        self.log(f"Removed {target_path}")
                    else:
                        QMessageBox.warning(self, "Error",
                                            f"Could not remove: {result.stderr}")
                        return
                except Exception as e:
                    QMessageBox.warning(self, "Error", f"Could not remove: {e}")
                    return

        self.log_text.clear()
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 0)
        self.build_btn.setEnabled(False)

        self.builder_thread = PackageBuilderThread(
            self.app_path_edit.text(),
            self.output_path_edit.text(),
            install_location,
            self.package_id_edit.text(),
            self.version_edit.text(),
            self.sign_identity_edit.text() if self.sign_checkbox.isChecked() else None
        )
        self.builder_thread.progress.connect(self.log)
        self.builder_thread.finished.connect(self.on_build_finished)
        self.builder_thread.start()

    def on_build_finished(self, success, message):
        self.progress_bar.setVisible(False)
        self.build_btn.setEnabled(True)
        self.log(message)
        if success:
            QMessageBox.information(self, "Success", message)
        else:
            QMessageBox.critical(self, "Error", message)

    def inspect_package(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Package to Inspect",
            os.path.expanduser("~/Desktop"),
            "Package Files (*.pkg)"
        )
        if not path:
            return

        self.log_text.clear()
        self.log(f"Inspecting: {path}")

        self.log("\n=== Package Contents ===")
        result = subprocess.run(
            ["pkgutil", "--payload-files", path],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            files = result.stdout.strip().split("\n")
            self.log(f"Total files: {len(files)}")
            for line in files[:50]:
                self.log(f"  {line}")
            if len(files) > 50:
                self.log(f"  … and {len(files) - 50} more")
        else:
            self.log(f"Error: {result.stderr}")

        self.log("\n=== Package Info ===")
        result = subprocess.run(
            ["pkgutil", "--pkg-info", path],
            capture_output=True, text=True
        )
        self.log(result.stdout if result.returncode == 0 else result.stderr)

        self.log("\n=== Component Plist (relocation flag) ===")
        # Expand the pkg to peek at the component plist
        expand_dir = Path("/tmp/pkg_inspect")
        shutil.rmtree(expand_dir, ignore_errors=True)
        exp = subprocess.run(
            ["pkgutil", "--expand", path, str(expand_dir)],
            capture_output=True, text=True
        )
        if exp.returncode == 0:
            for plist_path in expand_dir.rglob("PackageInfo"):
                self.log(f"  {plist_path}:")
                self.log(plist_path.read_text()[:800])
            shutil.rmtree(expand_dir, ignore_errors=True)
        else:
            self.log(f"Could not expand package: {exp.stderr}")

    def view_install_log(self):
        self.log_text.clear()
        self.log("=== macOS Installation Log (last 100 lines) ===\n")
        try:
            result = subprocess.run(
                ["tail", "-100", "/var/log/install.log"],
                capture_output=True, text=True
            )
            if result.returncode == 0:
                self.log(result.stdout)
            else:
                self.log("Could not read /var/log/install.log")
                self.log("Run in Terminal:  sudo tail -f /var/log/install.log")
        except Exception as e:
            self.log(f"Error: {e}")

    def check_installed_packages(self):
        self.log_text.clear()
        pkg_id = self.package_id_edit.text()
        if not pkg_id:
            self.log("Please enter a package identifier to search for.")
            return

        self.log(f"Checking for: {pkg_id}\n")

        self.log("=== Receipt ===")
        result = subprocess.run(
            ["pkgutil", "--pkg-info", pkg_id],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            self.log("✓ Package IS installed!")
            self.log(result.stdout)
        else:
            self.log("✗ Not in receipts database")
            list_result = subprocess.run(
                ["pkgutil", "--pkgs"], capture_output=True, text=True
            )
            if list_result.returncode == 0:
                matching = [p for p in list_result.stdout.split("\n")
                            if "death" in p.lower() or "deathshead" in p.lower()]
                if matching:
                    self.log("Similar packages found:")
                    for p in matching:
                        self.log(f"  {p}")

        self.log("\n=== Installed Files ===")
        files_result = subprocess.run(
            ["pkgutil", "--files", pkg_id], capture_output=True, text=True
        )
        if files_result.returncode == 0:
            files = files_result.stdout.strip().split("\n")
            self.log(f"{len(files)} files recorded:")
            for f in files[:50]:
                self.log(f"  {f}")
            if len(files) > 50:
                self.log(f"  … and {len(files) - 50} more")
        else:
            self.log("Could not list installed files.")

        self.log("\n=== /Applications ===")
        result = subprocess.run(["ls", "-la", "/Applications"],
                                capture_output=True, text=True)
        for line in result.stdout.split("\n"):
            if "death" in line.lower() or ".app" in line.lower():
                self.log(f"  {line}")


# =============================================================================
# Entry point
# =============================================================================
def main():
    # Silicon fix: must happen before QApplication()
    QApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)

    splash = create_splash()

    if splash:
        splash.show()
        splash.raise_()
        splash.activateWindow()
        app.processEvents()
        app.processEvents()

        messages = [
            ("Initializing Death's Head…",     1000),
            ("Loading Package Tools…",          1500),
            ("Preparing Build Environment…",    1400),
            ("Almost Ready…",                   1500),
        ]

        # Silicon splash fix: use QTimer + event loop instead of
        # QThread.msleep() which blocks the compositor and prevents
        # the splash from actually rendering on Apple Silicon.
        step = {"index": 0}

        def show_next_message():
            i = step["index"]
            if i < len(messages):
                msg, _ = messages[i]
                splash.showMessage(
                    "\n\n\n\n\n\n\n" + msg,
                    Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                    QColor(255, 255, 255)
                )
                splash.repaint()
                splash.raise_()
                step["index"] += 1
            else:
                timer.stop()
                splash.close()
                window = MainWindow()
                window.show()
                app._main_window = window  # prevent GC

        timer = QTimer()
        timer.timeout.connect(show_next_message)

        # Show the first message immediately, then start the timer
        show_next_message()
        timer.start(1350)  # ~5.4s total across 4 messages

        sys.exit(app.exec())
    else:
        window = MainWindow()
        window.show()
        sys.exit(app.exec())


if __name__ == "__main__":
    main()
